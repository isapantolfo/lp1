package entity;

import jakarta.persistence.*;
import java.util.*;

@Entity
@Table (name="acessorio_tb")


public class Acessorio {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;

    @Column
    private String tipo;

    @Column
    private String peca;

    @Column
    private Integer ocupacao;

    public Acessorio(String tipo, String peca, Integer ocupacao) {
        this.tipo = tipo;
        this.peca = peca;
        this.ocupacao = ocupacao;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPeca() {
        return peca;
    }

    public void setPeca(String peca) {
        this.peca = peca;
    }

    public Integer getOcupacao() {
        return ocupacao;
    }

    public void setOcupacao(Integer ocupacao) {
        this.ocupacao = ocupacao;
    }


    @Override
    public String toString() {
        return "Acessorio{" +
                "id=" + id +
                ", tipo='" + tipo + '\'' +
                ", peca='" + peca + '\'' +
                ", ocupacao=" + ocupacao +
                '}';
    }
}
