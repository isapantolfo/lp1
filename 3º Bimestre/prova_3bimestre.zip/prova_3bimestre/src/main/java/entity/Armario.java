package entity;

import jakarta.persistence.*;
import java.util.*;

@Entity
@Table (name="armario_tb")

public class Armario {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;

    @Column
    private Integer acessorio;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_dono")
    private Dono dono;

    @Column
    private Integer capacidade;

    @OneToMany (cascade = CascadeType.ALL, mappedBy = "armarios")
    @JoinColumn(name = "ListaAcessorios")
    private  List<Acessorio> acessoriosList = new ArrayList<>();

    @OneToMany (cascade = CascadeType.ALL, mappedBy = "armarios")
    @JoinColumn(name = "ListaAcessorios")
    private  List<Roupa> roupaList = new ArrayList<>();


    //CONSTRUTORES


    public Armario(Integer acessorio, Dono dono, Integer capacidade) {
        this.acessorio = acessorio;
        this.dono = dono;
        this.capacidade = capacidade;
        this.acessoriosList = new ArrayList();
        this.roupaList = new ArrayList();
    }

    //get e set

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAcessorio() {
        return acessorio;
    }

    public void setAcessorio(List<Acessorio> acessorio) {
        this.acessoriosList = acessorio;
    }

    public Dono getDono() {
        return dono;
    }

    public void setDono(Dono dono) {
        this.dono = dono;
    }

    public Integer getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(Integer capacidade) {
        this.capacidade = capacidade;
    }

    public List<Acessorio> getAcessoriosList() {
        return acessoriosList;
    }

    public void setAcessoriosList(List<Acessorio> acessoriosList) {
        this.acessoriosList = acessoriosList;
    }

    public List<Roupa> getRoupaList() {
        return roupaList;
    }

    public void setRoupaList(List<Roupa> roupaList) {
        this.roupaList = roupaList;
    }

    //to string

    @Override
    public String toString() {
        return "Armario{" +
                "id=" + id +
                ", acessorio=" + acessorio +
                ", dono=" + dono +
                ", capacidade=" + capacidade +
                ", acessoriosList=" + acessoriosList +
                ", roupaList=" + roupaList +
                '}';
    }


    public void setArmario (Armario Capaidade, Acessorio ocupacao, Roupa ocupacao){
        if (Capaidade.size> getAcessoriosList(ocupacao) + ocupacao)
            System.out.println("Item adicionado");

        else
            System.out.println("Capacidade");
    }
}



//
