package entity;

import jakarta.persistence.*;
import java.util.*;

@Entity
@Table (name="roupa_tb")

public class Roupa {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;

    @Column
    private String cor;

    @Column
    private String tamanho;

    @Column
    private Integer ocupacao;

    @Column
    private String peca;

    public Roupa(String cor, String tamanho, Integer ocupacao, String peca) {
        this.cor = cor;
        this.tamanho = tamanho;
        this.ocupacao = ocupacao;
        this.peca = peca;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public Integer getOcupacao() {
        return ocupacao;
    }

    public void setOcupacao(Integer ocupacao) {
        this.ocupacao = ocupacao;
    }

    public String getPeca() {
        return peca;
    }

    public void setPeca(String peca) {
        this.peca = peca;
    }

    @Override
    public String toString() {
        return "Roupa{" +
                "id=" + id +
                ", cor='" + cor + '\'' +
                ", tamanho='" + tamanho + '\'' +
                ", ocupacao=" + ocupacao +
                ", peca='" + peca + '\'' +
                '}';
    }
}
