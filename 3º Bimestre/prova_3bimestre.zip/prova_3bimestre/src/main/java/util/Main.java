package util;

import org.hibernate.Transaction;
import org.hibernate.Session;
import util.HibernateUtil;
import jakarta.persistence.*;

import entity.Acessorio;
import entity.Armario;
import entity.Dono;
import entity.Roupa;

import java.util.*;


public class Main {
    public static void main(String[] args) {

        Armario armario = new Armario(10, new Dono("Isabella"), 100);


        Dono dono1 = new Dono ("Isabella");

        Acessorio pulseira = new Acessorio("grande", "ouro", 10);
        Acessorio bracelete = new Acessorio("pequeno", "prata", 10);

        List <Acessorio> acessorioList = new ArrayList<>();
        acessorioList.add(pulseira);
        acessorioList.add(bracelete);


        Roupa camiseta = new Roupa("vermelho", "P", 20, "camiseta");
        Roupa calca = new Roupa ("verde", "M", 30, "calca");

        List <Roupa> roupaList = new ArrayList<>();
        roupaList.add(camiseta);
        roupaList.add(calca);

        armario.setAcessorio(acessorioList);
        armario.setRoupaList(roupaList);


        System.out.println(armario);


        Session session = HibernateUtil.getSessionFactory().openSession();

        Transaction transaction = session.beginTransaction();

        session.persist(armario);

        transaction.commit();


    }
}
